
require("dotenv").config();
const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "change-this-token";
const db = new Database(process.env.DB_PATH || path.join(__dirname, "scinova.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  excerpt TEXT,
  content TEXT NOT NULL,
  category TEXT DEFAULT 'SCIENCE',
  author TEXT DEFAULT 'SciNova India',
  read_time INTEGER DEFAULT 4,
  published INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  type TEXT,
  message TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname, "public")));

function admin(req,res,next){
  const token = req.headers.authorization?.replace(/^Bearer\s+/i,"") || req.query.token;
  if(!token || token !== ADMIN_TOKEN) return res.status(401).json({error:"Unauthorized"});
  next();
}

app.get("/api/health",(req,res)=>res.json({ok:true, service:"SciNova India Backend"}));

app.get("/api/articles",(req,res)=>{
  const published = req.query.published;
  let rows;
  if(published === "true"){
    rows = db.prepare("SELECT * FROM articles WHERE published=1 ORDER BY datetime(created_at) DESC").all();
  } else {
    rows = db.prepare("SELECT * FROM articles ORDER BY datetime(created_at) DESC").all();
  }
  res.json(rows);
});

app.post("/api/articles",admin,(req,res)=>{
  const {title,excerpt,content,category,author,read_time,published=true} = req.body;
  if(!title || !content) return res.status(400).json({error:"title and content are required"});
  const stmt = db.prepare(`INSERT INTO articles(title,excerpt,content,category,author,read_time,published)
    VALUES(@title,@excerpt,@content,@category,@author,@read_time,@published)`);
  const info = stmt.run({
    title, excerpt:excerpt||"", content,
    category:category||"SCIENCE", author:author||"SciNova India",
    read_time:Number(read_time)||4, published:published?1:0
  });
  res.json({ok:true,id:info.lastInsertRowid});
});

app.delete("/api/articles/:id",admin,(req,res)=>{
  db.prepare("DELETE FROM articles WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.post("/api/inquiries",(req,res)=>{
  const {name,email,type,message}=req.body;
  if(!name || !email || !message) return res.status(400).json({error:"Missing fields"});
  const info=db.prepare("INSERT INTO inquiries(name,email,type,message) VALUES(?,?,?,?)").run(name,email,type||"",message);
  res.json({ok:true,id:info.lastInsertRowid});
});

app.get("/api/inquiries",admin,(req,res)=>{
  res.json(db.prepare("SELECT * FROM inquiries ORDER BY datetime(created_at) DESC").all());
});

app.post("/api/newsletter",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase();
  if(!email) return res.status(400).json({error:"Email required"});
  try{
    db.prepare("INSERT INTO newsletter_subscribers(email) VALUES(?)").run(email);
    res.json({ok:true});
  }catch(e){ res.json({ok:true,alreadySubscribed:true}); }
});

app.get("/api/newsletter",admin,(req,res)=>{
  res.json(db.prepare("SELECT * FROM newsletter_subscribers ORDER BY datetime(created_at) DESC").all());
});

// Optional AI: set AI_API_KEY and AI_API_URL in .env.
// The endpoint expects an OpenAI-compatible JSON API.
app.post("/api/ai/chat", async (req,res)=>{
  const message=String(req.body.message||"").trim();
  if(!message) return res.status(400).json({error:"Message required"});

  const apiKey=process.env.AI_API_KEY;
  const apiUrl=process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions";
  const model=process.env.AI_MODEL || "gpt-5-mini";

  if(!apiKey){
    return res.json({reply:"SciNova AI is currently in demo mode. I can help with SciNova's STEM programs, I.N.V.E.N.T. Club, Campus Ambassador application, community joining and Dispatches. Add an AI_API_KEY in .env to enable live AI answers."});
  }

  try{
    const response=await fetch(apiUrl,{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${apiKey}`},
      body:JSON.stringify({
        model,
        messages:[
          {role:"system",content:"You are SciNova AI, a concise and friendly assistant for SciNova India, a student-led Science, Innovation & STEM community. Answer educationally, avoid making unsupported institutional claims, and encourage safe, age-appropriate STEM learning."},
          {role:"user",content:message}
        ],
        temperature:0.4
      })
    });
    const data=await response.json();
    if(!response.ok) throw new Error(data?.error?.message||"AI provider error");
    const reply=data?.choices?.[0]?.message?.content || "I could not generate a reply.";
    res.json({reply});
  }catch(err){
    res.status(502).json({error:"AI provider unavailable",detail:err.message});
  }
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));

app.listen(PORT,()=>console.log(`SciNova backend running on http://localhost:${PORT}`));
