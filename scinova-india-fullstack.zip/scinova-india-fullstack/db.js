// Database schema is initialized automatically by server.js using better-sqlite3.
module.exports = {};
